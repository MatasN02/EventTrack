export const firebaseConfig = {

  apiKey: "AIzaSyABsiKNOc1PHGERsuebPt34GovLh0AJ4eU",

  authDomain: "eventtrack-viko.firebaseapp.com",

  projectId: "eventtrack-viko",

  storageBucket: "eventtrack-viko.firebasestorage.app",

  messagingSenderId: "490124178376",

  appId: "1:490124178376:web:9a292998e9d246cfd606fd",

  measurementId: "G-P7S46LDMZR"

};
