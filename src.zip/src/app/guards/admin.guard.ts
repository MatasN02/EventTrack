import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { FirebaseService } from '../services/firebase.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {

  constructor(
    private firebase: FirebaseService,
    private router: Router
  ) { }

  async canActivate(): Promise<boolean> {

    const auth = this.firebase.getAuthInstance();
    const user = auth.currentUser;

    // ❌ Neprisijungęs
    if (!user) {
      console.warn('AdminGuard: no currentUser, redirect to /admin-login');
      this.router.navigateByUrl('/admin-login');
      return false;
    }

    console.log('AdminGuard: logged in as', user.email, 'uid:', user.uid);

    // 🔍 Gaunam rolę iš Firestore
    const role = await this.firebase.getUserRole(user.uid);
    console.log('AdminGuard: role from Firestore =', role);

    const normalizedRole = role ? role.toString().toUpperCase() : '';

    if (normalizedRole === 'ADMIN') {
      console.log('AdminGuard: access GRANTED');
      return true;
    }

    console.warn('AdminGuard: access DENIED, role =', role);
    alert('Neturite administratoriaus teisių');
    this.router.navigateByUrl('/login');
    return false;
  }
}
