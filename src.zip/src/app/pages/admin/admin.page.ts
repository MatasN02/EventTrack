import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import {
  collection,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  Firestore
} from 'firebase/firestore';
import { FirebaseService } from '../../services/firebase.service';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, IonicModule],
  templateUrl: './admin.page.html',
  styleUrls: ['./admin.page.scss']
})
export class AdminPage implements OnInit {

  events: any[] = [];
  loading = true;
  currentUser: User | null = null;

  constructor(private firebase: FirebaseService) { }

  ngOnInit() {
    const auth = getAuth();

    onAuthStateChanged(auth, async user => {
      this.currentUser = user;

      if (!user) {
        this.loading = false;
        console.warn('No user – redirect or show message here if needed.');
        return;
      }

      // TODO: if you have roles, you can check `user` custom claims here
      // and redirect if user is not an admin.

      await this.loadEvents();
    });
  }

  // 🔹 LOAD ALL EVENTS (admin sees *all*, including Pending/Rejected)
  async loadEvents() {
    this.loading = true;

    try {
      const db: Firestore = this.firebase.getDb();
      const snapshot = await getDocs(collection(db, 'events'));

      this.events = snapshot.docs.map(d => ({
        id: d.id,
        ...d.data()
      }));
    } catch (err) {
      console.error('ADMIN LOAD ERROR:', err);
      alert('Nepavyko užkrauti renginių (patikrink roles ir rules)');
    } finally {
      this.loading = false;
    }
  }

  // ✅ APPROVE
  async approveEvent(eventId: string) {
    try {
      const db = this.firebase.getDb();
      await updateDoc(doc(db, 'events', eventId), { status: 'Approved' });

      // atnaujinam lokaliai, kad nereiktų visko krauti iš naujo
      this.events = this.events.map(e =>
        e.id === eventId ? { ...e, status: 'Approved' } : e
      );
    } catch (err) {
      console.error('APPROVE ERROR:', err);
      alert('Nepavyko patvirtinti renginio');
    }
  }

  // ❌ REJECT
  async rejectEvent(eventId: string) {
    try {
      const db = this.firebase.getDb();
      await updateDoc(doc(db, 'events', eventId), { status: 'Rejected' });

      this.events = this.events.map(e =>
        e.id === eventId ? { ...e, status: 'Rejected' } : e
      );
    } catch (err) {
      console.error('REJECT ERROR:', err);
      alert('Nepavyko atmesti renginio');
    }
  }

  // 🗑 DELETE
  async deleteEvent(eventId: string) {
    const confirmed = confirm('Ar tikrai norite ištrinti renginį?');
    if (!confirmed) return;

    try {
      const db = this.firebase.getDb();
      await deleteDoc(doc(db, 'events', eventId));

      this.events = this.events.filter(e => e.id !== eventId);
    } catch (err) {
      console.error('DELETE ERROR:', err);
      alert('Nepavyko ištrinti renginio');
    }
  }
}
