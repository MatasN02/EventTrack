import { Injectable } from '@angular/core';
import { initializeApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  Auth,
  signInWithEmailAndPassword,
  signOut,
  UserCredential
} from 'firebase/auth';
import {
  getFirestore,
  Firestore,
  doc,
  getDoc
} from 'firebase/firestore';

import { firebaseConfig } from '../../environments/firebase';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  private app: FirebaseApp;
  private auth: Auth;
  private db: Firestore;

  constructor() {
    this.app = initializeApp(firebaseConfig);
    this.auth = getAuth(this.app);
    this.db = getFirestore(this.app);
  }

  // 🔹 Grąžinam Firestore DB instancą
  getDb(): Firestore {
    return this.db;
  }

  // 🔹 Grąžinam tą patį Auth instancą (naudojam guard'e)
  getAuthInstance(): Auth {
    return this.auth;
  }

  // 🔐 Login
  login(email: string, password: string): Promise<UserCredential> {
    return signInWithEmailAndPassword(this.auth, email, password);
  }

  // 🚪 Logout
  logout(): Promise<void> {
    return signOut(this.auth);
  }

  // 🔍 Perskaitom vartotojo rolę iš users/{uid}
  async getUserRole(uid: string): Promise<string | null> {
    const ref = doc(this.db, 'users', uid);
    const snap = await getDoc(ref);

    if (!snap.exists()) {
      console.warn('getUserRole: no user doc for uid', uid);
      return null;
    }

    const data = snap.data() as any;
    console.log('getUserRole: user data =', data);
    return data?.role ?? null;
  }

}
